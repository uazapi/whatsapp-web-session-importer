(() => {
  // src/customization.ts
  var EXTENSION_CUSTOMIZATION = {
    whatsappWebOrigin: "https://web.whatsapp.com",
    api: {
      clientBaseDomain: "uazapi.com",
      authHeaderName: "token",
      paths: {
        instanceStatus: "/instance/status",
        importWebSessionStart: "/instance/import-web-session/start",
        importWebSessionChunk: "/instance/import-web-session/chunk",
        importWebSessionFinish: "/instance/import-web-session/finish",
        importWebSessionHistory: "/instance/import-web-session/history"
      }
    },
    importLimits: {
      chunkItems: 1e3,
      historyChatLimit: 5e3
    },
    importDefaults: {
      // History is useful for continuity, but it depends on WhatsApp Web cache.
      // The service worker imports the session first and treats history failures
      // as warnings so this default cannot break the credential migration.
      includeHistory: true
    },
    appBridge: {
      source: "whatsapp-session-connector",
      matches: ["https://*.uazapi.com/*"]
    },
    panelText: {
      title: "Migrar sess\xE3o",
      defaultStatus: "WhatsApp Web conectado",
      loggedOutStatus: "Entre no WhatsApp Web para importar",
      clientLabel: "Nome da assinatura",
      clientPlaceholder: "ex: minha-loja",
      tokenLabel: "Token",
      tokenPlaceholder: "token",
      importButton: "Migrar sess\xE3o",
      diagnoseButton: "Baixar diagn\xF3stico",
      dumpHistoryButton: "Baixar hist\xF3rico",
      historyOnlyButton: "Repassar hist\xF3rico",
      dumpSessionButton: "Baixar sess\xE3o",
      exitDevModeButton: "Sair do modo t\xE9cnico",
      modeDefault: "Modo padr\xE3o",
      modeTechnical: "Modo t\xE9cnico",
      showToken: "Mostrar token",
      hideToken: "Ocultar token",
      clearToken: "Apagar token",
      closePanel: "Fechar painel",
      openSettings: "Configura\xE7\xF5es",
      closeSettings: "Fechar configura\xE7\xF5es",
      settingsTitle: "Configura\xE7\xF5es",
      autoOpenSetting: "Abrir painel automaticamente",
      autoOpenSettingHint: "Mesmo desativado, links com assinatura/token na URL sempre abrem o painel.",
      themeSetting: "Tema do painel",
      themeFollowWhatsApp: "Seguir WhatsApp",
      themeLight: "Claro",
      themeDark: "Escuro",
      includeHistory: "Incluir hist\xF3rico de mensagens (beta)",
      disconnectLocal: "Apagar a sess\xE3o local ap\xF3s importar",
      cleanupNoticeHTML: "<strong>Aten\xE7\xE3o:</strong> esta sess\xE3o ser\xE1 migrada para a assinatura informada e desconectada deste navegador.",
      keepLocalSessionWarningHTML: "<strong>Risco:</strong> manter a sess\xE3o neste navegador e na inst\xE2ncia ao mesmo tempo roda a mesma conta em dois lugares, o que pode causar desconex\xF5es, perda de mensagens e outros bugs. Use apenas para depura\xE7\xE3o.",
      extensionInvalidated: "A extens\xE3o foi atualizada ou recarregada. Recarregue esta aba do WhatsApp Web e tente novamente."
    }
  };

  // src/shared/config.ts
  var CLIENT_BASE_DOMAIN = EXTENSION_CUSTOMIZATION.api.clientBaseDomain;
  var WHATSAPP_WEB_ORIGIN = EXTENSION_CUSTOMIZATION.whatsappWebOrigin;
  var WHATSAPP_WEB_URL_PREFIX = `${WHATSAPP_WEB_ORIGIN}/`;
  var IMPORT_CHUNK_ITEMS = EXTENSION_CUSTOMIZATION.importLimits.chunkItems;
  var IMPORT_HISTORY_CHAT_LIMIT = EXTENSION_CUSTOMIZATION.importLimits.historyChatLimit;
  var DEFAULT_INCLUDE_HISTORY = EXTENSION_CUSTOMIZATION.importDefaults.includeHistory;
  var API_AUTH_HEADER_NAME = EXTENSION_CUSTOMIZATION.api.authHeaderName;
  var APP_BRIDGE_SOURCE = EXTENSION_CUSTOMIZATION.appBridge.source;
  var APP_BRIDGE_MATCHES = [...EXTENSION_CUSTOMIZATION.appBridge.matches];
  var APP_BRIDGE_MESSAGE_TYPES = {
    ready: "CONNECTOR_READY",
    ping: "PING",
    startImport: "START_IMPORT",
    openWhatsApp: "OPEN_WHATSAPP",
    started: "IMPORT_TAB_OPENED",
    error: "IMPORT_TAB_ERROR"
  };
  var API_PATHS = {
    instanceStatus: EXTENSION_CUSTOMIZATION.api.paths.instanceStatus,
    importWebSessionStart: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionStart,
    importWebSessionChunk: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionChunk,
    importWebSessionFinish: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionFinish,
    importWebSessionHistory: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionHistory
  };

  // src/content/app-bridge.ts
  var guard = window;
  if (!guard.__whatsAppSessionConnectorBridge) {
    guard.__whatsAppSessionConnectorBridge = true;
    const announce = () => {
      window.postMessage({
        source: APP_BRIDGE_SOURCE,
        type: APP_BRIDGE_MESSAGE_TYPES.ready,
        version: chrome.runtime?.getManifest?.().version || ""
      }, "*");
    };
    window.addEventListener("message", (event) => {
      if (event.source !== window) {
        return;
      }
      const data = event.data;
      if (!data || data.target !== APP_BRIDGE_SOURCE) {
        return;
      }
      if (data.type === APP_BRIDGE_MESSAGE_TYPES.ping) {
        announce();
        return;
      }
      if (data.type === APP_BRIDGE_MESSAGE_TYPES.startImport || data.type === APP_BRIDGE_MESSAGE_TYPES.openWhatsApp) {
        void chrome.runtime.sendMessage({
          type: APP_BRIDGE_MESSAGE_TYPES.startImport,
          client: data.client || "",
          token: data.token || ""
        }).then((response) => {
          window.postMessage({
            source: APP_BRIDGE_SOURCE,
            type: response?.ok ? APP_BRIDGE_MESSAGE_TYPES.started : APP_BRIDGE_MESSAGE_TYPES.error,
            error: response?.error || ""
          }, "*");
        }).catch((error) => {
          window.postMessage({
            source: APP_BRIDGE_SOURCE,
            type: APP_BRIDGE_MESSAGE_TYPES.error,
            error: error?.message || "Falha ao abrir WhatsApp Web"
          }, "*");
        });
      }
    });
    announce();
  }
})();
